This is a class assignment for group 8 members
